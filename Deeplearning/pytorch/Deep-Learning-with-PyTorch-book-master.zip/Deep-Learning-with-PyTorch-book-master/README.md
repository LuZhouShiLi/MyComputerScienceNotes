# PyTorch深度学习 开源电子书


基于PyTorch 1.x版！！！ 理论与实战结合，非常适合入门学习！！！


PDF下载: 👆👆👆👆  全书共430页，包含15章节。


很多同学Github不太会用，**直接Code->Download ZIP下载整个Github仓库，而不是点pdf文件去下载单个pdf文件**，Github是国外网站，国内支持不太好！


**News**:
- 20211218: 更新202112预览版，共430页，第8章和第14章尚未修改完成，其他章节可以使用
- 



![微信图片_20200707231347 - Copy](https://user-images.githubusercontent.com/4252555/146542031-5adae8e1-42d0-495f-890e-97e1754b4c83.jpg)


![image](https://user-images.githubusercontent.com/4252555/146542135-b8e971c2-87dd-4226-a48f-ce5d20163fca.png)
